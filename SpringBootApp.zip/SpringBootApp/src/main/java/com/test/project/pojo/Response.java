package com.test.project.pojo;

import lombok.Data;

@Data
public class Response {
    private String status;
    private String statusCode;
    private String message;
}
