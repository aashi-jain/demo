package com.test.project.service;


import com.test.project.pojo.Entity1;
import com.test.project.pojo.Entity2;
import com.test.project.pojo.Response;

public interface EntityService {

     String createEntity1(Entity1 entity1);
     String createEntity2(Entity2 entity2);
     String updateEntity1(Entity1 entity1);
     String updateEntity2(Entity2 entity2);
}
