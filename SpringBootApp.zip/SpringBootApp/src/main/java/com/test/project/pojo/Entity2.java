package com.test.project.pojo;

import lombok.Data;

@Data
public class Entity2 {

    public String id;
    public String name;
    public String state;
}
