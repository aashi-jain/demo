package com.test.project.controller;

import com.test.project.pojo.Entity1;
import com.test.project.pojo.Entity2;
import com.test.project.pojo.Response;
import com.test.project.service.EntityService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import static com.test.project.constant.Constant.*;

@RestController
public class EntityController {


    final EntityService entityService;
    Response response;

    public EntityController(EntityService entityService) {
        this.entityService = entityService;
    }

    /*post method to save entity1 ,take entity1 as input*/
    @PostMapping(value = "/createEntity1", consumes = "application/json", produces = "application/json")
    public Response createEntity1(@RequestBody Entity1 entity1) {
        response = new Response();
        try {
            String status = entityService.createEntity1(entity1);
            response.setStatus(status);
            response.setStatusCode(SUCCESS_CODE);
            response.setMessage("Entity1 entry created");
        } catch (Exception ex) {
            response.setStatus(FAILURE);
            response.setStatusCode(FAILURE_CODE);
            response.setMessage(ex.getMessage());
        }

        return response;
    }

    /*put method to update entity1 ,take entity1 as input*/
    @PutMapping(value = "/updateEntity1", consumes = "application/json", produces = "application/json")
    public Response updateEntity1(@RequestBody Entity1 entity1) {
        response = new Response();
        try {
            String status = entityService.updateEntity1(entity1);
            response.setStatus(status);
            response.setStatusCode(SUCCESS_CODE);
            response.setMessage("Entity1 entry updated");
        } catch (Exception ex) {
            response.setStatus(FAILURE);
            response.setStatusCode(FAILURE_CODE);
            response.setMessage(ex.getMessage());
        }
        return response;
    }

    /*post method to save entity2 ,take entity2 as input*/
    @PostMapping(value = "/createEntity2", consumes = "application/json", produces = "application/json")
    public Response createEntity2(@RequestBody Entity2 entity2) {
        response = new Response();
        try {
            String status = entityService.createEntity2(entity2);
            response.setStatus(status);
            response.setStatusCode(SUCCESS_CODE);
            response.setMessage("Entity2 entry created");
        } catch (Exception ex) {
            response.setStatus(FAILURE);
            response.setStatusCode(FAILURE_CODE);
            response.setMessage(ex.getMessage());
        }

        return response;
    }

    /*put method to update entity2 ,take entity2 as input*/
    @PutMapping(value = "/updateEntity2", consumes = "application/json", produces = "application/json")
    public Response updateEntity2(@RequestBody Entity2 entity2) {
        response = new Response();
        try {
            String status = entityService.updateEntity2(entity2);
            response.setStatus(status);
            response.setStatusCode(SUCCESS_CODE);
            response.setMessage("Entity2 entry updated");
        } catch (Exception ex) {
            response.setStatus(FAILURE);
            response.setStatusCode(FAILURE_CODE);
            response.setMessage(ex.getMessage());
        }
        return response;
    }
}
