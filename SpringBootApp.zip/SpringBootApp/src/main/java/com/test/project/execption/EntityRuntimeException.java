package com.test.project.execption;

public class EntityRuntimeException extends RuntimeException {
    public EntityRuntimeException(String message){
        super(message);
    }
}
