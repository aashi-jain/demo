package com.test.project.dao;

import com.test.project.pojo.Entity1;
import com.test.project.pojo.Entity2;

public interface EntityDao {

    String saveEntity1(Entity1 entity1);
    String saveEntity2(Entity2 entity2);
    String updateEntity1(Entity1 entity1);
    String updateEntity2(Entity2 entity2);
    Entity1 getEntity1(String id);
    Entity2 getEntity2(String id);
}
