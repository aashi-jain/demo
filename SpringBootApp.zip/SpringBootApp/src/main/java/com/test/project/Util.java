package com.test.project;

import java.util.*;

import static com.test.project.constant.Constant.*;

public class Util {
    //created static map to store state transition details for each state
    private static Map<String, List<String>> stateTransitionMap;

    static {
        stateTransitionMap = new HashMap<>();
        stateTransitionMap.put(STATE_1, Arrays.asList(STATE_1, STATE_2));
        stateTransitionMap.put(STATE_2, Arrays.asList(STATE_2, STATE_3, STATE_4));
        stateTransitionMap.put(STATE_3, Arrays.asList(STATE_3, STATE_2));
        stateTransitionMap.put(STATE_4, Arrays.asList(STATE_4));

    }

    public static Map<String, List<String>> getStateTransitionMap() {
        return stateTransitionMap;
    }
}
