package com.test.project.constant;

public interface Constant {

    String FAILURE = "Failure";
    String SUCCESS = "Success";
    String FAILURE_CODE = "204";
    String SUCCESS_CODE = "200";
    String STATE_1="State_1";
    String STATE_2="State_2";
    String STATE_3="State_3";
    String STATE_4="State_4";
}
