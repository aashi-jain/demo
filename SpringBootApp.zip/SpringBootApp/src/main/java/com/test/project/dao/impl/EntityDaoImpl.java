package com.test.project.dao.impl;

import com.test.project.dao.EntityDao;
import com.test.project.pojo.Entity1;
import com.test.project.pojo.Entity2;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

import static com.test.project.constant.Constant.SUCCESS;

@Repository
public class EntityDaoImpl implements EntityDao {

    private Map<String,Entity1> entity1Map = new HashMap<>();
    private Map<String,Entity2> entity2Map = new HashMap<>();

    @Override
    public String saveEntity1(Entity1 entity1) {
            //do stuff to save entity in db
        //for dummy implementation I am putting it in map
        entity1Map.put(entity1.getId(),entity1);
        return SUCCESS;
    }

    @Override
    public String saveEntity2(Entity2 entity2) {
        //do stuff to save entity in db
        //for dummy implementation I am putting it in map
        entity2Map.put(entity2.getId(),entity2);
        return SUCCESS;
    }

    @Override
    public String updateEntity1(Entity1 entity1) {
        //do stuff to update entity in db
        entity1Map.put(entity1.getId(),entity1);
        return SUCCESS;
    }

    @Override
    public String updateEntity2(Entity2 entity2) {
        //do stuff to update entity in db
        entity2Map.put(entity2.getId(),entity2);
        return SUCCESS;
    }

    @Override
    public Entity1 getEntity1(String id) {
        return entity1Map.get(id);
    }

    @Override
    public Entity2 getEntity2(String id) {
        return entity2Map.get(id);
    }


}
