package com.test.project.service.impl;

import com.test.project.Util;
import com.test.project.dao.EntityDao;
import com.test.project.execption.EntityRuntimeException;
import com.test.project.pojo.Entity1;
import com.test.project.pojo.Entity2;
import com.test.project.service.EntityService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import static com.test.project.constant.Constant.STATE_1;
import static com.test.project.constant.Constant.SUCCESS;

@Service
@EnableScheduling
public class EntityServiceImpl implements EntityService {
    private static final Logger LOGGER = LoggerFactory.getLogger(EntityServiceImpl.class);

    final EntityDao entityDao;

    public EntityServiceImpl(EntityDao entityDao) {
        this.entityDao = entityDao;
    }

    /* this method takes entity1 as input and store it in a map (DB)
     it check for id (null or duplicate check) and check for state*/
    @Override
    public String createEntity1(Entity1 entity1) throws EntityRuntimeException {
        /*putting this id check because id is unique ,and we are storing it in map
        in case of db store no need to check id ,it can be configured as auto generated field
         */
        if (ObjectUtils.isEmpty(entity1)) {
            LOGGER.error("Entity can not be null");
            throw new EntityRuntimeException("Entity can not be null");

        }
        if (ObjectUtils.isEmpty(entityDao.getEntity1(entity1.getId()))) {
            if (STATE_1.equalsIgnoreCase(entity1.getState())) {
                entityDao.saveEntity1(entity1);
            } else {
                LOGGER.error("Got wrong state :{} for entity1", entity1.getState());
                throw new EntityRuntimeException("Cannot create entity1 with state " + entity1.getState());
            }
        } else {
            LOGGER.error("Entity already exists with this id :{}", entity1.getId());
            throw new EntityRuntimeException("Entity already exists with this id " + entity1.getId());
        }
        return SUCCESS;
    }

    /* this method takes entity2 as input and store it in a map (DB)
     it check for id (null or duplicate check) and check for state*/
    @Override
    public String createEntity2(Entity2 entity2) {
        /*putting this id check because id is unique ,and we are storing it in map
        in case of db store no need to check id ,it can be configured as auto generated field
         */
        if (ObjectUtils.isEmpty(entity2)) {
            LOGGER.error("Entity can not be null");
            throw new EntityRuntimeException("Entity can not be null");

        }
        if (ObjectUtils.isEmpty(entityDao.getEntity2(entity2.getId()))) {
            if (STATE_1.equalsIgnoreCase(entity2.getState())) {
                entityDao.saveEntity2(entity2);
            } else {
                LOGGER.error("Got wrong state :{} for entity2", entity2.getState());
                throw new EntityRuntimeException("Cannot create entity2 with state " + entity2.getState());
            }
        } else {
            LOGGER.error("Entity already exists with this id :{}", entity2.getId());
            throw new EntityRuntimeException("Entity already exists with this id " + entity2.getId());
        }
        return SUCCESS;
    }

    /* this method takes entity1 as input and get the existing entity from a map (DB) based on id
     and validate state according to transition diagram and update it back*/
    @Override
    public String updateEntity1(Entity1 entity1) {
        if (ObjectUtils.isEmpty(entity1)) {
            LOGGER.error("Entity can not be null");
            throw new EntityRuntimeException("Entity can not be null");

        }
        Entity1 existingEntity1 = entityDao.getEntity1(entity1.getId());
        if (!ObjectUtils.isEmpty(existingEntity1) && !ObjectUtils.isEmpty(entity1) && !ObjectUtils.isEmpty(entity1.getState())) {
            if (Util.getStateTransitionMap().get(existingEntity1.getState()).contains(entity1.getState())) {
                entityDao.saveEntity1(entity1);
            } else {
                LOGGER.error("Got wrong state :{} for entity1", entity1.getState());
                throw new EntityRuntimeException("Cannot update entity1 with state " + entity1.getState());
            }
        } else {
            LOGGER.error("Entity does not exists with this id :{}", entity1.getId());
            throw new EntityRuntimeException("Entity does not exists with this id " + entity1.getId());
        }
        return SUCCESS;
    }

    /* this method takes entity2 as input and get the existing entity from a map (DB) based on id
       and validate state according to transition diagram and update it back*/
    @Override
    public String updateEntity2(Entity2 entity2) {
        if (ObjectUtils.isEmpty(entity2)) {
            LOGGER.error("Entity can not be null");
            throw new EntityRuntimeException("Entity can not be null");

        }
        Entity2 existingEntity2 = entityDao.getEntity2(entity2.getId());
        if (!ObjectUtils.isEmpty(existingEntity2) && !ObjectUtils.isEmpty(entity2) && !ObjectUtils.isEmpty(entity2.getState())) {
            if (Util.getStateTransitionMap().get(existingEntity2.getState()).contains(entity2.getState())) {
                entityDao.saveEntity2(entity2);
            } else {
                LOGGER.error("Got wrong state :{} for entity2", entity2.getState());
                throw new EntityRuntimeException("Cannot update entity2 with state " + entity2.getState());
            }
        } else {
            LOGGER.error("Entity does not exists with this id :{}", entity2.getId());
            throw new EntityRuntimeException("Entity does not exists with this id " + entity2.getId());
        }
        return SUCCESS;
    }
}
