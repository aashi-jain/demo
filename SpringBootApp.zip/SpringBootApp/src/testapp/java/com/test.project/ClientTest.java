package com.test.project;

import com.test.project.pojo.Entity1;
import com.test.project.pojo.Entity2;
import com.test.project.pojo.Response;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

import static com.test.project.constant.Constant.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT, classes = {SpringBootProjectApplication.class})
public class ClientTest {
    @Autowired
    private RestTemplate restTemplate;

    @Test
    public void createEntity1() {
        Entity1 entity1 = new Entity1();
        entity1.setId("1");
        entity1.setName("A");
        entity1.setState(STATE_1);

        Entity1 updatedEntity1 = new Entity1();
        updatedEntity1.setId("1");
        updatedEntity1.setName("A");
        updatedEntity1.setState(STATE_2);

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<Entity1> httpEntity = new HttpEntity<>(entity1, headers);
        Response createResponse = restTemplate.exchange("http://localhost:8080/createEntity1", HttpMethod.POST, httpEntity, Response.class).getBody();
        System.out.println("Status code : " + createResponse.getStatusCode());
        System.out.println("Status code : " + createResponse.getMessage());
        HttpEntity<Entity1> updatedHttpEntity = new HttpEntity<>(updatedEntity1, headers);
        Response updateResponse = restTemplate.exchange("http://localhost:8080/updateEntity1", HttpMethod.PUT, updatedHttpEntity, Response.class).getBody();
        System.out.println("Status code : " + updateResponse.getStatusCode());
        System.out.println("Status code : " + updateResponse.getMessage());
    }
    
    @Test
    public void createEntity2() {
        Entity2 entity2 = new Entity2();
        entity2.setId("1");
        entity2.setName("A");
        entity2.setState(STATE_1);

        Entity2 updatedEntity2 = new Entity2();
        updatedEntity2.setId("1");
        updatedEntity2.setName("A");
        updatedEntity2.setState(STATE_2);

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<Entity2> httpEntity = new HttpEntity<>(entity2, headers);
        Response createResponse = restTemplate.exchange("http://localhost:8080/createEntity2", HttpMethod.POST, httpEntity, Response.class).getBody();
        System.out.println("Status code : " + createResponse.getStatusCode());
        System.out.println("Status code : " + createResponse.getMessage());
        HttpEntity<Entity2> updatedHttpEntity = new HttpEntity<>(updatedEntity2, headers);
        Response updateResponse = restTemplate.exchange("http://localhost:8080/updateEntity2", HttpMethod.PUT, updatedHttpEntity, Response.class).getBody();
        System.out.println("Status code : " + updateResponse.getStatusCode());
        System.out.println("Status code : " + updateResponse.getMessage());
    }
}
