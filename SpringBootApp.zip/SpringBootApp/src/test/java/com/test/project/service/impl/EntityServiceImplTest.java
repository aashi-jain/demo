package com.test.project.service.impl;

import com.test.project.dao.EntityDao;
import com.test.project.execption.EntityRuntimeException;
import com.test.project.pojo.Entity1;
import com.test.project.pojo.Entity2;
import com.test.project.pojo.Response;
import com.test.project.service.EntityService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import static com.test.project.constant.Constant.*;
import static org.junit.jupiter.api.Assertions.*;

class EntityServiceImplTest {
    @Mock
    EntityDao entityDao;
    EntityService entityService;
    Entity1 entity1;
    Entity2 entity2;

    @BeforeEach
    void setUp() {
        entityDao = Mockito.mock(EntityDao.class);
        entityService = new EntityServiceImpl(entityDao);
    }

    @Test
    void createEntity1Success() {
        entity1 = new Entity1();
        entity1.setId("1");
        entity1.setName("A");
        entity1.setState(STATE_1);
        Mockito.when(entityDao.saveEntity1(entity1)).thenReturn(SUCCESS);
        String actualResponse = entityService.createEntity1(entity1);
        assertEquals(actualResponse, SUCCESS);
    }

    @Test
    void createEntity1FailureWithWrongState() {
        entity1 = new Entity1();
        entity1.setId("1");
        entity1.setName("A");
        entity1.setState(STATE_2);
        try {
            entityService.createEntity1(entity1);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Cannot create entity1 with state " + entity1.getState());
        }
    }

    @Test
    void createEntity1FailureWithNullEntity() {
        try {
            entityService.createEntity1(entity1);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Entity can not be null");
        }
    }

    @Test
    void createEntity1FailureWithNullState() {
        entity1 = new Entity1();
        entity1.setId("1");
        entity1.setName("A");
        entity1.setState(null);
        try {
            entityService.createEntity1(entity1);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Cannot create entity1 with state " + entity1.getState());
        }
    }

    @Test
    void createEntity1FailureWithExistingEntity() {
        entity1 = new Entity1();
        entity1.setId("1");
        entity1.setName("A");
        entity1.setState(STATE_1);
        Mockito.when(entityDao.getEntity1("1")).thenReturn(entity1);
        try {
            entityService.createEntity1(entity1);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Entity already exists with this id " + entity1.getId());
        }
    }

    @Test
    void createEntity2Success() {
        entity2 = new Entity2();
        entity2.setId("1");
        entity2.setName("A");
        entity2.setState(STATE_1);
        Mockito.when(entityDao.saveEntity2(entity2)).thenReturn(SUCCESS);
        String actualResponse = entityService.createEntity2(entity2);
        assertEquals(actualResponse, SUCCESS);
    }

    @Test
    void createEntity2FailureWithNullEntity() {
        try {
            entityService.createEntity2(entity2);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Entity can not be null");
        }
    }

    @Test
    void createEntity2FailureWithWrongState() {
        entity2 = new Entity2();
        entity2.setId("1");
        entity2.setName("A");
        entity2.setState(STATE_2);
        try {
            entityService.createEntity2(entity2);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Cannot create entity2 with state " + entity2.getState());
        }
    }

    @Test
    void createEntity2FailureWithNullState() {
        entity2 = new Entity2();
        entity2.setId("1");
        entity2.setName("A");
        entity2.setState(null);
        try {
            entityService.createEntity2(entity2);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Cannot create entity2 with state " + entity2.getState());
        }
    }

    @Test
    void createEntity2FailureWithExistingEntity() {
        entity2 = new Entity2();
        entity2.setId("1");
        entity2.setName("A");
        entity2.setState(STATE_1);
        Mockito.when(entityDao.getEntity2("1")).thenReturn(entity2);
        try {
            entityService.createEntity2(entity2);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Entity already exists with this id " + entity2.getId());
        }
    }

    @Test
    void updateEntity1() {

        entity1 = new Entity1();
        entity1.setId("1");
        entity1.setName("A");
        entity1.setState(STATE_1);

        Entity1 entity1Updated = new Entity1();
        entity1Updated.setId("1");
        entity1Updated.setName("A");
        entity1Updated.setState(STATE_2);
        Mockito.when(entityDao.getEntity1("1")).thenReturn(entity1);
        Mockito.when(entityDao.updateEntity1(entity1Updated)).thenReturn(SUCCESS);
        String actualResponse = entityService.updateEntity1(entity1Updated);
        assertEquals(actualResponse, SUCCESS);

    }

    @Test
    void updateEntity1FailureWithNullEntity() {
        try {
            entityService.updateEntity1(entity1);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Entity can not be null");
        }
    }

    @Test
    void updateEntity1WithWrongState() {
        Entity1 entity1Updated = new Entity1();
        try {
            entity1 = new Entity1();
            entity1.setId("1");
            entity1.setName("A");
            entity1.setState(STATE_1);

            entity1Updated.setId("1");
            entity1Updated.setName(entity1.getName());
            entity1Updated.setState(STATE_4);
            Mockito.when(entityDao.getEntity1("1")).thenReturn(entity1);
            entityService.updateEntity1(entity1Updated);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Cannot update entity1 with state " + entity1Updated.getState());
        }


    }

    @Test
    void updateEntity1WithNonExistingEntity() {
        try {
            entity1 = new Entity1();
            entity1.setId("1");
            entity1.setName("A");
            entity1.setState(STATE_1);

            entityService.updateEntity1(entity1);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Entity does not exists with this id " + entity1.getId());
        }


    }

    @Test
    void updateEntity2() {

        entity2 = new Entity2();
        entity2.setId("1");
        entity2.setName("A");
        entity2.setState(STATE_1);

        Entity2 entity2Updated = new Entity2();
        entity2Updated.setId("1");
        entity2Updated.setName("A");
        entity2Updated.setState(STATE_2);
        Mockito.when(entityDao.getEntity2("1")).thenReturn(entity2);
        Mockito.when(entityDao.updateEntity2(entity2Updated)).thenReturn(SUCCESS);
        String actualResponse = entityService.updateEntity2(entity2Updated);
        assertEquals(actualResponse, SUCCESS);

    }

    @Test
    void updateEntity2FailureWithNullEntity() {
        try {
            entityService.updateEntity2(entity2);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Entity can not be null");
        }
    }

    @Test
    void updateEntity2WithWrongState() {
        Entity2 entity2Updated = new Entity2();
        try {
            entity2 = new Entity2();
            entity2.setId("1");
            entity2.setName("A");
            entity2.setState(STATE_1);

            entity2Updated.setId("1");
            entity2Updated.setName(entity2.getName());
            entity2Updated.setState(STATE_4);
            Mockito.when(entityDao.getEntity2("1")).thenReturn(entity2);
            entityService.updateEntity2(entity2Updated);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Cannot update entity2 with state " + entity2Updated.getState());
        }


    }

    @Test
    void updateEntity2WithNonExistingEntity() {
        try {
            entity2 = new Entity2();
            entity2.setId("1");
            entity2.setName("A");
            entity2.setState(STATE_1);

            entityService.updateEntity2(entity2);
        } catch (EntityRuntimeException ex) {
            assertEquals(ex.getMessage(), "Entity does not exists with this id " + entity2.getId());
        }


    }


}