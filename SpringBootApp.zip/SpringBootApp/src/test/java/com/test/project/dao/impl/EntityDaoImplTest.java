package com.test.project.dao.impl;

import com.test.project.dao.EntityDao;
import com.test.project.pojo.Entity1;
import com.test.project.pojo.Entity2;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static com.test.project.constant.Constant.STATE_1;
import static com.test.project.constant.Constant.SUCCESS;
import static org.junit.jupiter.api.Assertions.*;

class EntityDaoImplTest {

    EntityDao entityDao;
    Entity1 entity1;
    Entity2 entity2;

    @BeforeEach
    void setUp() {
        entityDao = new EntityDaoImpl();
        entity2 = new Entity2();
        entity2.setId("1");
        entity2.setName("A");
        entity2.setState(STATE_1);

        entity1 = new Entity1();
        entity1.setId("1");
        entity1.setName("A");
        entity1.setState(STATE_1);
    }

    @Test
    void saveEntity1() {
        String result= entityDao.saveEntity1(entity1);
        assertEquals(SUCCESS,result);
    }

    @Test
    void saveEntity2() {
        String result= entityDao.saveEntity1(entity1);
        assertEquals(SUCCESS,result);
    }

    @Test
    void updateEntity1() {
        String result= entityDao.updateEntity1(entity1);
        assertEquals(SUCCESS,result);
    }

    @Test
    void updateEntity2() {
        String result= entityDao.updateEntity2(entity2);
        assertEquals(SUCCESS,result);
    }

    @Test
    void getEntity1() {
        entityDao.saveEntity1(entity1);
        Entity1 actualEntity1 = entityDao.getEntity1(entity1.getId());
        assertEquals(actualEntity1,entity1);
    }

    @Test
    void getEntity2() {
        entityDao.saveEntity2(entity2);
        Entity2 actualEntity2 = entityDao.getEntity2(entity2.getId());
        assertEquals(actualEntity2,entity2);
    }
}