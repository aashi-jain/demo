package com.test.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT ,classes = {SpringBootProjectApplication.class})
class SpringBootProjectApplicationTests {

    @Test
    void contextLoads() {
        System.out.println("Context Loaded");
    }

}
