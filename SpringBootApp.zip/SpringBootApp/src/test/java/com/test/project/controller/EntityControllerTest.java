package com.test.project.controller;

import com.test.project.dao.EntityDao;
import com.test.project.execption.EntityRuntimeException;
import com.test.project.pojo.Entity1;
import com.test.project.pojo.Entity2;
import com.test.project.pojo.Response;
import com.test.project.service.EntityService;
import com.test.project.service.impl.EntityServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import static com.test.project.constant.Constant.*;
import static org.mockito.Mockito.when;

class EntityControllerTest {

    @Mock
    EntityService entityService;
    EntityController entityController;
    EntityController entityControllerException;
    Response expectedSuccessResponse;
    Response expectedFailureResponse;
    Entity1 entity1;
    Entity2 entity2;
    @Mock
    EntityDao entityDao;
    EntityService entityServiceException;

    @BeforeEach
    void setUp() {
        entityDao =Mockito.mock(EntityDao.class);
        entityService = Mockito.mock(EntityServiceImpl.class);
        entityController = new EntityController(entityService);

        entityServiceException = new EntityServiceImpl(entityDao);
        entityControllerException = new EntityController(entityServiceException);
        entity1 = new Entity1();
        entity2 = new Entity2();
        setUpSuccessResponse();
        setUpFailureResponse();
    }

    @Test
    void createEntity1() {
        when(entityService.createEntity1(entity1)).thenReturn(SUCCESS);
        expectedSuccessResponse.setMessage("Entity1 entry created");
        Response actualResponse = entityController.createEntity1(entity1);
        Assertions.assertEquals(actualResponse, expectedSuccessResponse);
    }

    @Test
    void updateEntity1() {
        when(entityService.updateEntity1(entity1)).thenReturn(SUCCESS);
        expectedSuccessResponse.setMessage("Entity1 entry updated");
        Response actualResponse = entityController.updateEntity1(entity1);
        Assertions.assertEquals(actualResponse, expectedSuccessResponse);
    }

    @Test
    void createEntity2() {
        when(entityService.createEntity2(entity2)).thenReturn(SUCCESS);
        expectedSuccessResponse.setMessage("Entity2 entry created");
        Response actualResponse = entityController.createEntity2(entity2);
        Assertions.assertEquals(actualResponse, expectedSuccessResponse);
    }

    @Test
    void updateEntity2() {
        when(entityService.updateEntity2(entity2)).thenReturn(SUCCESS);
        expectedSuccessResponse.setMessage("Entity2 entry updated");
        Response actualResponse = entityController.updateEntity2(entity2);
        Assertions.assertEquals(actualResponse, expectedSuccessResponse);
    }

    @Test
    void createEntity1Exception() {
        Response actualResponse = entityControllerException.createEntity1(null);
        expectedFailureResponse.setMessage("Entity can not be null");
        Assertions.assertEquals(actualResponse, expectedFailureResponse);
    }

    @Test
    void updateEntity1Exception() {
        Response actualResponse = entityControllerException.updateEntity1(null);
        expectedFailureResponse.setMessage("Entity can not be null");
        Assertions.assertEquals(actualResponse, expectedFailureResponse);
    }

    @Test
    void createEntity2Exception() {
        Response actualResponse = entityControllerException.createEntity2(null);
        expectedFailureResponse.setMessage("Entity can not be null");
        Assertions.assertEquals(actualResponse, expectedFailureResponse);
    }

    @Test
    void updateEntity2Exception() {
        Response actualResponse = entityControllerException.updateEntity2(null);
        expectedFailureResponse.setMessage("Entity can not be null");
        Assertions.assertEquals(actualResponse, expectedFailureResponse);
    }

    void setUpSuccessResponse() {
        expectedSuccessResponse = new Response();
        expectedSuccessResponse.setStatus(SUCCESS);
        expectedSuccessResponse.setStatusCode(SUCCESS_CODE);
    }

    void setUpFailureResponse() {
        expectedFailureResponse = new Response();
        expectedFailureResponse.setStatus(FAILURE);
        expectedFailureResponse.setStatusCode(FAILURE_CODE);
    }
}